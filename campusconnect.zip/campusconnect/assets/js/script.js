// =============================
// CampusConnect SPA Script
// =============================

// Global JSON data
let campusData = {};

// Load JSON data on page load
$(document).ready(function () {
  $.getJSON("data/campusconnect.json", function (data) {
    campusData = data.campusConnect;

    // Load Home by default
    loadHome();

    // Setup navigation clicks
    setupNavigation();
  });
});

// =============================
// SPA Navigation
// =============================
function setupNavigation() {
  $(document).on("click", "a[data-page]", function (e) {
    e.preventDefault();
    let page = $(this).data("page");

    switch (page) {
      case "home": loadHome(); break;
      case "about": loadAbout(); break;
      case "events": loadEvents(); break;
      case "gallery": loadGallery(); break;
      case "contact": loadContact(); break;
      case "feedback": loadFeedback(); break;
      default:
        $("#content").html(`<h2 class="text-center">Page Not Found</h2>`);
    }
  });
}

// =============================
// HOME PAGE
// =============================
function loadHome() {
  let today = new Date();

  // Separate events into upcoming & past
  let upcomingEvents = campusData.events.filter(e => new Date(e.endDate) >= today);
  let pastEvents = campusData.events.filter(e => new Date(e.endDate) < today);

  let html = `
    <!-- Moving Welcome Message -->
    <div class="welcome-marquee text-white py-2 mt-5">
      <div class="marquee-text">
        ${campusData.banner.welcomeMessage}
      </div>
    </div>

    <!-- Banner Carousel -->
    <div id="carouselBanner" class="carousel slide mb-4" data-bs-ride="carousel">
      <div class="carousel-inner">
  `;

  campusData.banner.banners.forEach((banner, i) => {
    html += `
      <div class="carousel-item ${i === 0 ? 'active' : ''}">
        <img  height="400px" src="assets/img/banners/${banner.image}" class="d-block w-100" alt="${banner.title}">
        <div class="carousel-caption d-none d-md-block">
          <h5>${banner.title}</h5>
        </div>
      </div>
    `;
  });

  html += `
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselBanner" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselBanner" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
      </button>
    </div>

    <!-- Upcoming Events -->
    <h3 class="mb-3">Upcoming Events</h3>
    <div class="row">
  `;

  if (upcomingEvents.length === 0) {
    html += `<p>No upcoming events right now.</p>`;
  }

  upcomingEvents.forEach(event => {
  html += `
     <div class="col-md-4">
      <div class="card event-card border-0 shadow-lg mb-4">
        
        <!-- Event Image with overlay -->
        <div class="event-img-container">
          <img height="300px" src="assets/img/banners/${event.image}" class="card-img-top" alt="${event.name}">
          <div class="event-overlay">
            <span class="badge bg-primary">${event.category}</span>
            <span class="badge bg-info text-dark">${event.department}</span>
          </div>
        </div>

        <div class="card-body">
          <h5 class="card-title fw-bold">${event.name}</h5>
          <p class="mb-1"><i class="bi bi-calendar-event"></i> <strong>Start:</strong> ${event.date}</p>
          <p class="mb-1"><i class="bi bi-calendar-check"></i> <strong>End:</strong> ${event.endDate}</p>
          <p class="mb-1"><i class="bi bi-clock"></i> <strong>Time:</strong> ${event.time}</p>
          <p class="mb-2"><i class="bi bi-geo-alt"></i> <strong>Venue:</strong> ${event.venue}</p>

          <!-- Countdown -->
          <i class="bi bi-clock"></i>Countdown:
          <div id="countdown-${event.id}" class="countdown badge bg-dark text-white p-2 mb-3">
          </div>

          <!-- Learn More -->
          <a href="#" class="btn btn-primary w-100 learn-more"
            data-id="${event.id}" 
            data-name="${event.name}" 
             data-description="${event.description}" 
            data-date="${event.date}" 
            data-end="${event.endDate}" 
            data-time="${event.time}" 
            data-venue="${event.venue}" 
            data-dept="${event.department}" 
            data-category="${event.category}" 
            data-img="${event.image}" 
             data-organizer="${event.organizer}" 
            data-bs-toggle="modal" 
            data-bs-target="#eventModal">
            <i class="bi bi-info-circle"></i> Learn More
          </a>
        </div>
      </div>
    </div>
  `;
});

  html += `</div>`;

  // Past events
  html += `
    <h3 class="mb-3">Past Events</h3>
    <div class="row">
  `;

  if (pastEvents.length === 0) {
    html += `<p>No past events yet.</p>`;
  }

  pastEvents.forEach(event => {
    html += `
     <div class="col-md-4">
      <div class="card event-card border-0 shadow-lg mb-4">
        
        <!-- Event Image with overlay -->
        <div class="event-img-container">
          <img height="300px" src="assets/img/banners/${event.image}" class="card-img-top" alt="${event.name}">
          <div class="event-overlay">
            <span class="badge bg-primary">${event.category}</span>
            <span class="badge bg-info text-dark">${event.department}</span>
          </div>
        </div>

        <div class="card-body">
          <h5 class="card-title fw-bold">${event.name}</h5>
          <p class="mb-1"><i class="bi bi-calendar-event"></i> <strong>Start:</strong> ${event.date}</p>
          <p class="mb-1"><i class="bi bi-calendar-check"></i> <strong>End:</strong> ${event.endDate}</p>
          <p class="mb-1"><i class="bi bi-clock"></i> <strong>Time:</strong> ${event.time}</p>
          <p class="mb-2"><i class="bi bi-geo-alt"></i> <strong>Venue:</strong> ${event.venue}</p>

          <!-- Countdown -->
          <div id="countdown-${event.id}" class="countdown badge bg-dark text-white p-2 mb-3"></div>

          <!-- Learn More -->
          <a href="#" class="btn btn-primary w-100 learn-more"
            data-id="${event.id}" 
            data-name="${event.name}" 
             data-description="${event.description}" 
            data-date="${event.date}" 
            data-end="${event.endDate}" 
            data-time="${event.time}" 
            data-venue="${event.venue}" 
            data-dept="${event.department}" 
            data-category="${event.category}" 
            data-img="${event.image}" 
             data-organizer="${event.organizer}" 
            data-bs-toggle="modal" 
            data-bs-target="#eventModal">
            <i class="bi bi-info-circle"></i> Learn More
          </a>
        </div>
      </div>
    </div>
    `;
  });

  html += `</div>`;
  $("#content").html(html);

  // Start countdowns for upcoming only
  upcomingEvents.forEach(event => {
    startCountdown(event.id, event.date, event.time);
  });

  // Bind modal details
  $(".learn-more").click(function () {
  $("#eventModalLabel").text($(this).data("name"));
  $("#eventModalImg").attr("src", "assets/img/banners/" + $(this).data("img"));
  $("#eventModalDesc").html(`
    <div class="alert alert-info">
      <i class="bi bi-info-circle-fill"></i> ${$(this).data("description")}
    </div>
  `);

  $("#eventModalDetails").html(`
    <div class="row text-start">
      <div class="col-md-6 mb-2">
        <i class="bi bi-calendar-event text-primary"></i> 
        <strong>Start Date:</strong> ${$(this).data("date")}
      </div>
      <div class="col-md-6 mb-2">
        <i class="bi bi-calendar-check text-success"></i> 
        <strong>End Date:</strong> ${$(this).data("end")}
      </div>
      <div class="col-md-6 mb-2">
        <i class="bi bi-clock text-warning"></i> 
        <strong>Time:</strong> ${$(this).data("time")}
      </div>
      <div class="col-md-6 mb-2">
        <i class="bi bi-geo-alt text-danger"></i> 
        <strong>Venue:</strong> ${$(this).data("venue")}
      </div>
      <div class="col-md-6 mb-2">
        <span class="badge bg-primary"><i class="bi bi-building"></i> ${$(this).data("dept")}</span>
      </div>
      <div class="col-md-6 mb-2">
        <span class="badge bg-dark"><i class="bi bi-tags"></i> ${$(this).data("category")}</span>
      </div>
      <div class="col-12 mt-2">
        <i class="bi bi-person-badge text-secondary"></i> 
        <strong>Organizer:</strong> ${$(this).data("organizer")}
      </div>
    </div>
  `);
});
}

// =============================
// ABOUT PAGE
// =============================
function loadAbout() {
  let today = new Date();

  // Store original events
  let upcomingEvents = campusData.events.filter(e => new Date(e.endDate) >= today);
  let pastEvents = campusData.events.filter(e => new Date(e.endDate) < today);

  let html = ``;


  
  // -------- Hero Section --------
  html += `
  <!-- About Page Hero Section -->
  <section class="mt-5 about-hero text-center text-white d-flex align-items-center justify-content-center"
    style="background: linear-gradient(rgba(0,0,50,0.7), rgba(5, 5, 56, 0.7)), url('assets/img/hero-section.jpeg') center/cover no-repeat; height: 60vh; border-radius: 0 0 50px 50px;">
    <div class="container" >
      <h1 class="display-4 fw-bold mb-3">CampusConnect</h1>
      <h1 class="display-4 fw-bold mb-3">College of Engineering</h1>
      <p class="lead mb-4">
        Located in Karachi, affiliated with <strong>FAST University</strong>.  
        A hub for academic excellence, innovation, and vibrant cultural activities.
      </p>
      <div class="row justify-content-center">
        <div class="col-md-3 mb-3">
          <div class="card bg-light text-dark border-0 shadow-sm h-100">
            <div class="card-body">
              <i class="bi bi-award-fill text-primary display-5"></i>
              <h6 class="mt-2 fw-bold">Recognized Excellence</h6>
              <p class="small">Ranked among the top institutes in technology & innovation.</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card bg-light text-dark border-0 shadow-sm h-100">
            <div class="card-body">
              <i class="bi bi-people-fill text-success display-5"></i>
              <h6 class="mt-2 fw-bold">Cultural Diversity</h6>
              <p class="small">Annual events & festivals celebrating talent and creativity.</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card bg-light text-dark border-0 shadow-sm h-100">
            <div class="card-body">
              <i class="bi bi-mortarboard-fill text-danger display-5"></i>
              <h6 class="mt-2 fw-bold">Academic Brilliance</h6>
              <p class="small">Strong focus on innovation, research, and skill-building.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  `;


  // Add Filter + Sort UI
  
  html += `
  <div class="d-flex flex-wrap justify-content-between align-items-center mb-4" style="margin-top:100px">
    <!-- Filter -->
    <div class="mb-2">
      <label class="me-2 fw-bold">Filter by Category:</label>
      <select id="eventFilter" class="form-select d-inline-block w-auto">
        <option value="all">All</option>
        <option value="Technical">Technical</option>
        <option value="Cultural">Cultural</option>
        <option value="Sports">Sports</option>
        <option value="Mackup">Mackup</option>
        <option value="Departmental">Departmental</option>
      </select>
    </div>

    <!-- Sort -->
    <div class="mb-2">
      <label class="me-2 fw-bold">Sort by:</label>
      <select id="eventSort" class="form-select d-inline-block w-auto">
        <option value="dateAsc">Date (Upcoming First)</option>
        <option value="dateDesc">Date (Most Recent First)</option>
        <option value="nameAsc">Name (A → Z)</option>
        <option value="nameDesc">Name (Z → A)</option>
        <option value="category">Category</option>
      </select>
    </div>
  </div>
`;





  html += `<div id="eventContainer"></div>`;
  $("#content").html(html);

  // Render Events Initially
  renderEvents(upcomingEvents, pastEvents);

  // Handle Filter + Sort
  $("#eventFilter, #eventSort").on("change", function () {
    let filterVal = $("#eventFilter").val();
    let sortVal = $("#eventSort").val();

    let filteredUpcoming = upcomingEvents.filter(ev => filterVal === "all" || ev.category === filterVal);
    let filteredPast = pastEvents.filter(ev => filterVal === "all" || ev.category === filterVal);

    // Sorting Logic
    const sortEvents = (arr) => {
      switch (sortVal) {
        case "dateAsc":
          return arr.sort((a, b) => new Date(a.date) - new Date(b.date));
        case "dateDesc":
          return arr.sort((a, b) => new Date(b.date) - new Date(a.date));
        case "nameAsc":
          return arr.sort((a, b) => a.name.localeCompare(b.name));
        case "nameDesc":
          return arr.sort((a, b) => b.name.localeCompare(a.name));
        case "category":
          return arr.sort((a, b) => a.category.localeCompare(b.category));
        default:
          return arr;
      }
    };

    filteredUpcoming = sortEvents(filteredUpcoming);
    filteredPast = sortEvents(filteredPast);

    renderEvents(filteredUpcoming, filteredPast);
  });

  // Helper: Render Events
  function renderEvents(upcoming, past) {
    let eventHTML = ``;

    // Upcoming
    eventHTML += `<h3 class="mb-3">Upcoming Events</h3><div class="row">`;
    if (upcoming.length === 0) {
      eventHTML += `<p>No upcoming events right now.</p>`;
    } else {
      upcoming.forEach(event => {
        eventHTML += buildEventCard(event, true);
      });
    }
    eventHTML += `</div>`;

    // Past
    eventHTML += `<h3 class="mb-3 mt-4">Past Events</h3><div class="row">`;
    if (past.length === 0) {
      eventHTML += `<p>No past events yet.</p>`;
    } else {
      past.forEach(event => {
        eventHTML += buildEventCard(event, false);
      });
    }
    eventHTML += `</div>`;

    $("#eventContainer").html(eventHTML);

    // Restart countdown for filtered upcoming
    upcoming.forEach(event => startCountdown(event.id, event.date, event.time));

    // Re-bind modal
    bindEventModal();
  }

  // Helper: Build Card
  function buildEventCard(event, withCountdown) {
    return `
      <div class="col-md-4">
        <div class="card event-card border-0 shadow-lg mb-4">
          <div class="event-img-container">
            <img height="300px" src="assets/img/banners/${event.image}" class="card-img-top" alt="${event.name}">
            <div class="event-overlay">
              <span class="badge bg-primary">${event.category}</span>
              <span class="badge bg-info text-dark">${event.department}</span>
            </div>
          </div>
          <div class="card-body">
            <h5 class="card-title fw-bold">${event.name}</h5>
            <p class="mb-1"><i class="bi bi-calendar-event"></i> <strong>Start:</strong> ${event.date}</p>
            <p class="mb-1"><i class="bi bi-calendar-check"></i> <strong>End:</strong> ${event.endDate}</p>
            <p class="mb-1"><i class="bi bi-clock"></i> <strong>Time:</strong> ${event.time}</p>
            <p class="mb-2"><i class="bi bi-geo-alt"></i> <strong>Venue:</strong> ${event.venue}</p>
            ${withCountdown ? `<div id="countdown-${event.id}" class="countdown badge bg-dark text-white p-2 mb-3"></div>` : ""}
            <a href="#" class="btn btn-primary w-100 learn-more"
              data-id="${event.id}" 
              data-name="${event.name}" 
              data-description="${event.description}" 
              data-date="${event.date}" 
              data-end="${event.endDate}" 
              data-time="${event.time}" 
              data-venue="${event.venue}" 
              data-dept="${event.department}" 
              data-category="${event.category}" 
              data-img="${event.image}" 
              data-organizer="${event.organizer}" 
              data-bs-toggle="modal" 
              data-bs-target="#eventModal">
              <i class="bi bi-info-circle"></i> Learn More
            </a>
          </div>
        </div>
      </div>
    `;
  }

  // Helper: Bind Modal
  function bindEventModal() {
    $(".learn-more").click(function () {
      $("#eventModalLabel").text($(this).data("name"));
      $("#eventModalImg").attr("src", "assets/img/banners/" + $(this).data("img"));
      $("#eventModalDesc").html(`
        <div class="alert alert-info">
          <i class="bi bi-info-circle-fill"></i> ${$(this).data("description")}
        </div>
      `);
      $("#eventModalDetails").html(`
        <div class="row text-start">
          <div class="col-md-6 mb-2"><i class="bi bi-calendar-event text-primary"></i> <strong>Start:</strong> ${$(this).data("date")}</div>
          <div class="col-md-6 mb-2"><i class="bi bi-calendar-check text-success"></i> <strong>End:</strong> ${$(this).data("end")}</div>
          <div class="col-md-6 mb-2"><i class="bi bi-clock text-warning"></i> <strong>Time:</strong> ${$(this).data("time")}</div>
          <div class="col-md-6 mb-2"><i class="bi bi-geo-alt text-danger"></i> <strong>Venue:</strong> ${$(this).data("venue")}</div>
          <div class="col-md-6 mb-2"><span class="badge bg-primary"><i class="bi bi-building"></i> ${$(this).data("dept")}</span></div>
          <div class="col-md-6 mb-2"><span class="badge bg-dark"><i class="bi bi-tags"></i> ${$(this).data("category")}</span></div>
          <div class="col-12 mt-2"><i class="bi bi-person-badge text-secondary"></i> <strong>Organizer:</strong> ${$(this).data("organizer")}</div>
        </div>
      `);
    });
  }
}




// =============================
// EVENTS PAGE
// =============================
function loadEvents() {
  let html = `<h2>All Events</h2><div class="row">`;

  campusData.events.forEach(event => {
    html += `
      <div class="col-md-4">
        <div class="card shadow-sm mb-4">
          <img src="assets/img/events/${event.image}" class="card-img-top" alt="${event.name}">
          <div class="card-body">
            <h5>${event.name}</h5>
            <p><strong>Date:</strong> ${event.date}</p>
            <p><strong>Venue:</strong> ${event.venue}</p>
            <p>${event.description}</p>
          </div>
        </div>
      </div>
    `;
  });

  html += `</div>`;
  $("#content").html(html);
}

// =============================
// GALLERY PAGE
// =============================
function loadGallery() {
  let html = `
    <h2 class="mb-4 text-center" style="margin-top:100px">Gallery Page</h2>

    <!-- Gallery Tabs -->
    <ul class="nav nav-tabs justify-content-center mb-4" id="galleryTabs">
      <li class="nav-item">
        <a class="nav-link active" href="#" data-mode="year">By Year</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#" data-mode="category">By Category</a>
      </li>
    </ul>

    <!-- Gallery Content -->
    <div id="galleryContent"></div>

    <!-- Modal for Image Preview -->
    <div class="modal fade" id="galleryModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-body p-0">
            <img id="galleryModalImg" src="" class="img-fluid w-100 rounded">
          </div>
        </div>
      </div>
    </div>
  `;

  $("#content").html(html);

  let currentMode = "year"; // default view

  function renderGallery() {
    let grouped = {};

    // -------- Group Event Images --------
    campusData.events.forEach(event => {
      let eventYear = new Date(event.date).getFullYear();
      let key = currentMode === "year" ? `${eventYear}` : event.category;

      if (!grouped[key]) grouped[key] = [];
      grouped[key].push({
        img: `assets/img/banners/${event.image}`,
        name: event.name,
        date: event.date
      });
    });

    // -------- Render Images --------
    let innerHtml = ``;
    Object.keys(grouped).forEach(key => {
      innerHtml += `<h4 class="mt-4">${key}</h4><div class="row mb-4">`;

      grouped[key].forEach(event => {
        innerHtml += `
          <div class="col-md-3 col-sm-6 mb-3">
            <div class="card border-0 shadow-sm h-100">
              <img height="400px" width="400px" src="${event.img}" 
                   class="img-fluid rounded gallery-img" 
                   alt="${event.name}"
                   data-bs-toggle="modal" 
                   data-bs-target="#galleryModal" 
                   data-img="${event.img}">
              <div class="card-body p-2 text-center">
                <small class="fw-bold d-block">${event.name}</small>
                <small class="text-muted">${event.date}</small>
              </div>
            </div>
          </div>
        `;
      });

      innerHtml += `</div>`;
    });

    $("#galleryContent").html(innerHtml);

    // Preview Modal
    $(".gallery-img").click(function () {
      $("#galleryModalImg").attr("src", $(this).data("img"));
    });
  }

  // Tab switching
  $("#galleryTabs .nav-link").click(function (e) {
    e.preventDefault();
    $("#galleryTabs .nav-link").removeClass("active");
    $(this).addClass("active");
    currentMode = $(this).data("mode");
    renderGallery();
  });

  // Initial load
  renderGallery();
}

// =============================
// CONTACT PAGE
// =============================
function loadContact() {
  let html = `
    <div class="container my-5">
      <h2 class="text-center mb-5 fw-bold text-white">📞 Meet Our Coordinators</h2>

      <!-- Tabs -->
      <ul class="nav nav-pills justify-content-center mb-4 gap-3" id="contactTabs" role="tablist">
        <li class="nav-item" role="presentation">
          <button class="nav-link active px-4 py-2 rounded-pill shadow-sm text-white bg-primary border-0" 
                  id="faculty-tab" data-bs-toggle="tab" data-bs-target="#faculty" type="button" role="tab">
            👩‍🏫 Faculty
          </button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link px-4 py-2 rounded-pill shadow-sm text-white bg-success border-0" 
                  id="student-tab" data-bs-toggle="tab" data-bs-target="#student" type="button" role="tab">
            🎓 Students
          </button>
        </li>
      </ul>

      <div class="tab-content">
        <!-- Faculty Tab -->
        <div class="tab-pane fade show active" id="faculty" role="tabpanel">
          <div class="row g-4">
  `;

  // Faculty Contacts
  campusData.contacts
    .filter(p => p.role === "Faculty")
    .forEach(person => {
      html += `
        <div class="col-md-4">
          <div class="card border-0 shadow-lg rounded-4 h-100 hover-card bg-dark text-white">
            <div class="text-center p-4">
              <img src="${person.photo}" class="rounded-circle mb-3 shadow-sm border border-3 border-light" 
                   alt="${person.name}" style="width:120px; height:120px; object-fit:cover;">
              <h5 class="fw-bold">${person.name}</h5>
              <p class="mb-1 text-light">${person.designation}</p>
              <p class="small"><i class="bi bi-building"></i> ${person.department}</p>
              <hr class="border-light">
              <p class="mb-1"><i class="bi bi-telephone-fill text-success"></i> 
                <a href="tel:${person.phone}" class="text-decoration-none text-info">${person.phone}</a>
              </p>
              <p><i class="bi bi-envelope-fill text-danger"></i> 
                <a href="mailto:${person.email}" class="text-decoration-none text-warning">${person.email}</a>
              </p>
              <span class="badge bg-primary px-3 py-2">${person.role}</span>
            </div>
          </div>
        </div>
      `;
    });

  html += `
          </div>
        </div>

        <!-- Student Tab -->
        <div class="tab-pane fade" id="student" role="tabpanel">
          <div class="row g-4">
  `;

  // Student Contacts
  campusData.contacts
    .filter(p => p.role === "Student")
    .forEach(person => {
      html += `
        <div class="col-md-4">
          <div class="card border-0 shadow-lg rounded-4 h-100 hover-card bg-secondary text-white">
            <div class="text-center p-4">
              <img src="${person.photo}" class="rounded-circle mb-3 shadow-sm border border-3 border-light" 
                   alt="${person.name}" style="width:120px; height:120px; object-fit:cover;">
              <h5 class="fw-bold">${person.name}</h5>
              <p class="mb-1 text-light">${person.designation}</p>
              <p class="small"><i class="bi bi-building"></i> ${person.department}</p>
              <hr class="border-light">
              <p class="mb-1"><i class="bi bi-telephone-fill text-success"></i> 
                <a href="tel:${person.phone}" class="text-decoration-none text-info">${person.phone}</a>
              </p>
              <p><i class="bi bi-envelope-fill text-danger"></i> 
                <a href="mailto:${person.email}" class="text-decoration-none text-warning">${person.email}</a>
              </p>
              <span class="badge bg-success px-3 py-2">${person.role}</span>
            </div>
          </div>
        </div>
      `;
    });

  html += `
          </div>
        </div>
      </div>

      <!-- Google Map -->
      <div class="mt-5">
        <h4 class="mb-3 fw-bold text-white">📍 Our Campus Location</h4>
        <div class="ratio ratio-16x9 shadow rounded-4 border border-light">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3620.0170064238873!2d67.07182317586773!3d24.86326874514427!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33ea3db108f41%3A0x42acc4507358b160!2sAptech%20Learning%2C%20Shahrah%20e%20Faisal%20Center!5e0!3m2!1sen!2s!4v1757518007014!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>

    <style>
      body { background: #121212; }  /* Dark background */
      .hover-card { transition: transform 0.3s ease, box-shadow 0.3s ease; }
      .hover-card:hover { transform: translateY(-8px); box-shadow: 0 12px 30px rgba(255,255,255,0.2); }
    </style>
  `;

  $("#content").html(html);
}


// =============================
// FEEDBACK PAGE
// =============================
function loadFeedback() {
  let html = `
    <div class="container my-5" style="max-width: 800px;">
      <h2 class="text-center mb-4">📝 Feedback Form</h2>
      <p class="text-center text-muted">
        Share your thoughts about our recent events. Your feedback helps us improve!
      </p>

      <form class="shadow-lg p-4 rounded bg-light">
        <!-- Name -->
        <div class="mb-3">
          <label for="feedbackName" class="form-label fw-bold">Name</label>
          <input type="text" class="form-control" id="feedbackName" placeholder="Enter your full name">
        </div>

        <!-- Email -->
        <div class="mb-3">
          <label for="feedbackEmail" class="form-label fw-bold">Email</label>
          <input type="email" class="form-control" id="feedbackEmail" placeholder="Enter your email">
        </div>

        <!-- User Type -->
        <div class="mb-3">
          <label for="feedbackUserType" class="form-label fw-bold">User Type</label>
          <select class="form-select" id="feedbackUserType">
            <option selected disabled>Select your role</option>
            <option>Student</option>
            <option>Faculty</option>
            <option>Guest</option>
          </select>
        </div>

        <!-- Event Attended -->
        <div class="mb-3">
          <label for="feedbackEvent" class="form-label fw-bold">Event Attended</label>
          <select class="form-select" id="feedbackEvent">
            <option selected disabled>Select an event</option>
          </select>
        </div>

        <!-- Rating with Stars -->
        <div class="mb-3">
          <label class="form-label fw-bold">Rating</label>
          <div id="starRating" class="d-flex gap-2 fs-3 text-warning">
            <i class="bi bi-star" data-value="1"></i>
            <i class="bi bi-star" data-value="2"></i>
            <i class="bi bi-star" data-value="3"></i>
            <i class="bi bi-star" data-value="4"></i>
            <i class="bi bi-star" data-value="5"></i>
          </div>
          <input type="hidden" id="feedbackRating" value="0">
        </div>

        <!-- Comments -->
        <div class="mb-3">
          <label for="feedbackComments" class="form-label fw-bold">Comments</label>
          <textarea class="form-control" id="feedbackComments" rows="4" placeholder="Write your suggestions here..."></textarea>
        </div>

        <!-- Button -->
        <button type="button" class="btn btn-primary w-100">
          <i class="bi bi-send"></i> Submit Feedback
        </button>
      </form>
    </div>
  `;

  // Render into page
  $("#content").html(html);

  // =============================
  // Populate Event Attended (last 1 month events)
  // =============================
  let today = new Date();
  let oneMonthAgo = new Date();
  oneMonthAgo.setMonth(today.getMonth() - 1);

  let eventDropdown = $("#feedbackEvent");
  let pastMonthEvents = campusData.events.filter(e => {
    let eventDate = new Date(e.date);
    return eventDate >= oneMonthAgo && eventDate <= today;
  });

  if (pastMonthEvents.length === 0) {
    eventDropdown.append(`<option disabled>No recent events</option>`);
  } else {
    pastMonthEvents.forEach(event => {
      eventDropdown.append(`<option>${event.name}</option>`);
    });
  }

  // =============================
  // Star Rating Logic
  // =============================
  $("#starRating i").on("click", function () {
    let rating = $(this).data("value");
    $("#feedbackRating").val(rating);

    // Highlight stars
    $("#starRating i").each(function () {
      if ($(this).data("value") <= rating) {
        $(this).removeClass("bi-star").addClass("bi-star-fill");
      } else {
        $(this).removeClass("bi-star-fill").addClass("bi-star");
      }
    });
  });
}




// =============================
// Countdown Function
// =============================
function startCountdown(id, date, time) {
  let target = new Date(date + " " + time.split("-")[0].trim()).getTime();

  let interval = setInterval(function() {
    let now = new Date().getTime();
    let distance = target - now;

    if (distance < 0) {
      $("#countdown-" + id).html("Event Started");
      clearInterval(interval);
      return;
    }

    let days = Math.floor(distance / (1000 * 60 * 60 * 24));
    let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let mins = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    let secs = Math.floor((distance % (1000 * 60)) / 1000);

    $("#countdown-" + id).html(`${days}d ${hours}h ${mins}m ${secs}s`);
  }, 1000);
}
