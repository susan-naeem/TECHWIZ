 let events = [];
let currentCategory = "all";

$(document).ready(function () {
  // Load event data
  $.getJSON("events.json", function (data) {
    events = data;
    renderEvents(events);
  });

  // Category tab click
  $("#categoryTabs .nav-link").click(function () {
    $("#categoryTabs .nav-link").removeClass("active");
    $(this).addClass("active");

    currentCategory = $(this).data("category");
    applyFilters();
  });

  // Sort dropdown
  $('#sortBy').change(function () {
    applyFilters();
  });
});

function applyFilters() {
  let filtered = [...events];
  let sortBy = $('#sortBy').val();

  // Filter by category
  if (currentCategory !== "all") {
    filtered = filtered.filter(event => event.category === currentCategory);
  }

  // Sort logic
  if (sortBy === "date") {
    filtered.sort((a, b) => new Date(a.date) - new Date(b.date));
  } else if (sortBy === "name") {
    filtered.sort((a, b) => a.name.localeCompare(b.name));
  } else if (sortBy === "category") {
    filtered.sort((a, b) => a.category.localeCompare(b.category));
  }

  renderEvents(filtered);
}

function renderEvents(data) {
  $('#eventList').empty();

  if (data.length === 0) {
    $('#eventList').html('<div class="text-center text-muted">No events found for this category.</div>');
    return;
  }

  data.forEach(event => {
    const date = new Date(event.date);
    const formattedDate = date.toLocaleString('en-GB', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });

    const card = `
      <div class="col-md-6 col-lg-4">
        <div class="card shadow-sm p-3 h-100">
          <div class="card-body d-flex flex-column">
            <img src="${event.img}" alt="">
            <h5 class="card-title">${event.name}</h5>
            <p class="event-date mb-1">📅 ${formattedDate}</p>
            <p class="event-category mb-2">🏷️ ${event.category}</p>
            <p class="card-text">${event.description}</p>
            <p class="mt-auto mb-0"><strong>📍 ${event.venue}</strong></p>
          </div>
        </div>
      </div>
    `;
    $('#eventList').append(card);
  });
}
