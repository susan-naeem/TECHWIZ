$(document).ready(function () {
  // Load page into #content
  function loadPage(page) {
   
    if (page === "home") {
      loadHome(); // call your existing function
      $(".nav-link").removeClass("active");
      $(`.nav-link[data-page="home"]`).addClass("active");
      return;
    }


    $("#content").load(`pages/${page}.html`, function (response, status) {
      if (status === "error") {
        $("#content").html(`
          <div class="alert alert-danger mt-5">
            <strong>Error:</strong> Could not load ${page}.html
          </div>
        `);
      }
    });

    // Update active nav link
    $(".nav-link").removeClass("active");
    $(`.nav-link[data-page="${page}"]`).addClass("active");
  }

  // Get page from hash (#home, #about, etc.)
  function getPageFromHash() {
    let hash = location.hash.replace("#", "");
    return hash ? hash : "home"; // default
  }

  // Initial load
  let page = getPageFromHash();
  loadPage(page);

  // Handle nav clicks
  $(document).on("click", "[data-page]", function (e) {
    e.preventDefault();
    let page = $(this).data("page");
    location.hash = page; // update hash in URL
  });

  // Handle hash changes (back/forward)
  $(window).on("hashchange", function () {
    let page = getPageFromHash();
    loadPage(page);
  });





// Global JSON data
let campusData = {};


  $.getJSON("data/campusconnect.json", function (data) {
    campusData = data.campusConnect;


  });






function loadHome() {
  let today = new Date();

  // Separate events into upcoming & past
  let upcomingEvents = campusData.events.filter(e => new Date(e.endDate) >= today);
  let pastEvents = campusData.events.filter(e => new Date(e.endDate) < today);

  // Load bookmarks from localStorage (or [] if none)
  let bookmarks = JSON.parse(localStorage.getItem("bookmarkedEvents") || "[]");

  let html = `
    <!-- Moving Welcome Message -->
    <div class="welcome-marquee text-white py-2 mt-5 bg-primary">
      <div class="marquee-text px-3 fw-semibold" style="font-size: 1.25rem;">
        ${campusData.banner.welcomeMessage}
      </div>
    </div>

    <!-- Banner Carousel -->
    <div id="carouselBanner" class="carousel slide mb-5 shadow-lg rounded" data-bs-ride="carousel" data-bs-interval="4000">
      <div class="carousel-inner rounded">
  `;

  campusData.banner.banners.forEach((banner, i) => {
    html += `
      <div class="carousel-item ${i === 0 ? 'active' : ''}">
        <img height="400px" src="assets/img/banners/${banner.image}" class="d-block w-100 rounded" alt="${banner.title}">
        <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
          <h5 class="text-white fw-bold">${banner.title}</h5>
        </div>
      </div>
    `;
  });

  html += `
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselBanner" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselBanner" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>

    <!-- Upcoming Events -->
    <h3 class="mb-4 text-center fw-bold text-primary">Upcoming Events</h3>
    <div class="row g-4 justify-content-center">
  `;

  if (upcomingEvents.length === 0) {
    html += `<p class="text-center fst-italic">No upcoming events right now.</p>`;
  }

  upcomingEvents.forEach(event => {
    const isBookmarked = bookmarks.includes(event.id);

    html += `
     <div class="col-sm-12 col-md-6 col-lg-4">
      <div class="card event-card border-0 shadow-lg mb-4 hover-scale rounded-4 overflow-hidden">
        <div class="event-img-container position-relative overflow-hidden">
          <img height="280px" src="assets/img/banners/${event.image}" class="card-img-top object-fit-cover" alt="${event.name}">
          <div class="event-overlay position-absolute top-0 start-0 w-100 h-100 d-flex flex-column justify-content-between p-3">
            <div>
              <span class="badge bg-primary me-1 fs-6">${event.category}</span>
              <span class="badge bg-info text-dark fs-6">${event.department}</span>
            </div>
            <div class="text-white text-end" style="text-shadow: 0 0 6px rgba(0,0,0,0.7); font-weight: 600;">
              ${event.date} - ${event.endDate}
            </div>
          </div>
        </div>

        <div class="card-body">
          <h5 class="card-title fw-bold">${event.name}</h5>
          <p class="mb-1"><i class="bi bi-clock-history text-warning"></i> ${event.time} at ${event.venue}</p>

          <!-- Countdown -->
          <div id="countdown-${event.id}" class="countdown badge bg-dark text-white p-2 mb-3 d-inline-block fs-6 rounded-pill"></div>

          <!-- Buttons -->
          <div class="d-flex gap-2">
            <a href="#" class="btn btn-primary w-100 learn-more shadow-sm"
              data-id="${event.id}" 
              data-name="${event.name}" 
              data-description="${event.description}" 
              data-date="${event.date}" 
              data-end="${event.endDate}" 
              data-time="${event.time}" 
              data-venue="${event.venue}" 
              data-dept="${event.department}" 
              data-category="${event.category}" 
              data-img="${event.image}" 
              data-organizer="${event.organizer}" 
              data-bs-toggle="modal" 
              data-bs-target="#eventModal">
              <i class="bi bi-info-circle"></i> Learn More
            </a>
            <button class="btn ${isBookmarked ? "btn-warning" : "btn-outline-warning"} bookmark-btn" data-id="${event.id}">
              <i class="bi ${isBookmarked ? "bi-star-fill" : "bi-star"}"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
  });

  html += `</div>`;

  // 🔹 Bookmarked Events Section
  if (bookmarks.length > 0) {
    html += `
      <h3 class="mt-5 mb-4 text-center fw-bold text-warning">⭐ Your Bookmarked Events</h3>
      <div id="bookmarked-events" class="row g-4 justify-content-center"></div>
    `;
  }

  // Past events
  html += `
    <h3 class="mb-4 mt-5 text-center fw-bold text-secondary">Past Events</h3>
    <div class="row g-4 justify-content-center">
  `;

  if (pastEvents.length === 0) {
    html += `<p class="text-center fst-italic">No past events yet.</p>`;
  }

  pastEvents.forEach(event => {
    html += `
     <div class="col-sm-12 col-md-6 col-lg-4">
      <div class="card event-card border-0 shadow-sm mb-4 hover-scale rounded-4 overflow-hidden">
        <div class="event-img-container position-relative overflow-hidden">
          <img height="280px" src="assets/img/banners/${event.image}" class="card-img-top object-fit-cover" alt="${event.name}">
          <div class="event-overlay position-absolute top-0 start-0 w-100 h-100 d-flex flex-column justify-content-between p-3">
            <div>
              <span class="badge bg-primary me-1 fs-6">${event.category}</span>
              <span class="badge bg-info text-dark fs-6">${event.department}</span>
            </div>
            <div class="text-white text-end" style="text-shadow: 0 0 6px rgba(0,0,0,0.7); font-weight: 600;">
              ${event.date} - ${event.endDate}
            </div>
          </div>
        </div>

        <div class="card-body">
          <h5 class="card-title fw-bold">${event.name}</h5>
          <p class="mb-1"><i class="bi bi-clock-history text-warning"></i> ${event.time} at ${event.venue}</p>

          <a href="#" class="btn btn-outline-secondary w-100 learn-more shadow-sm"
            data-id="${event.id}" 
            data-name="${event.name}" 
            data-description="${event.description}" 
            data-date="${event.date}" 
            data-end="${event.endDate}" 
            data-time="${event.time}" 
            data-venue="${event.venue}" 
            data-dept="${event.department}" 
            data-category="${event.category}" 
            data-img="${event.image}" 
            data-organizer="${event.organizer}" 
            data-bs-toggle="modal" 
            data-bs-target="#eventModal">
            <i class="bi bi-info-circle"></i> Learn More
          </a>
        </div>
      </div>
    </div>
    `;
  });

  html += `</div>`;
  $("#content").html(html);

  // Start countdowns for upcoming only
  upcomingEvents.forEach(event => {
    startCountdown(event.id, event.date, event.time);
  });

  // Bind modal details
  $(".learn-more").click(function () {
  const name = $(this).data("name");
  const img = $(this).data("img");
  const description = $(this).data("description");
  const date = $(this).data("date");
  const end = $(this).data("end");
  const time = $(this).data("time");
  const venue = $(this).data("venue");
  const dept = $(this).data("dept");
  const category = $(this).data("category");
  const organizer = $(this).data("organizer");

  // Modal Title
  $("#eventModalLabel").text(name);

  // Modal Image
  $("#eventModalImg").attr("src", "assets/img/banners/" + img);

  // Modal Description
  $("#eventModalDesc").html(`
    <div class="alert alert-info d-flex align-items-center gap-2">
      <i class="bi bi-info-circle-fill fs-4"></i> ${description}
    </div>
  `);

  // Other Details
  $("#eventModalDetails").html(`
    <li class="list-group-item"><strong>Date:</strong> ${date} - ${end}</li>
    <li class="list-group-item"><strong>Time:</strong> ${time}</li>
    <li class="list-group-item"><strong>Venue:</strong> ${venue}</li>
    <li class="list-group-item"><strong>Department:</strong> ${dept}</li>
    <li class="list-group-item"><strong>Category:</strong> ${category}</li>
    <li class="list-group-item"><strong>Organizer:</strong> ${organizer}</li>
  `);
});

  // 🔹 Bookmark toggle handler
  $(".bookmark-btn").click(function () {
    const eventId = $(this).data("id");
    let current = JSON.parse(localStorage.getItem("bookmarkedEvents") || "[]");

    if (current.includes(eventId)) {
      current = current.filter(id => id !== eventId); // remove
    } else {
      current.push(eventId); // add
    }

    localStorage.setItem("bookmarkedEvents", JSON.stringify(current));
    loadHome(); // re-render
  });

  // 🔹 Render bookmarked section if needed
  if (bookmarks.length > 0) {
    let bookmarkedHtml = "";
    campusData.events
      .filter(ev => bookmarks.includes(ev.id))
      .forEach(ev => {
        bookmarkedHtml += `
          <div class="col-sm-12 col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100">
              <img height="300px" src="assets/img/banners/${ev.image}" class="card-img-top" alt="${ev.name}">
              <div class="card-body">
                <h5 class="card-title">${ev.name}</h5>
                <p class="small text-light">${ev.date} at ${ev.venue}</p>
              </div>
            </div>
          </div>
        `;
      });

    $("#bookmarked-events").html(bookmarkedHtml);
  }
}




 // Handle Bookmark Click
$(document).off("click", ".bookmark-btn").on("click", ".bookmark-btn", function () {
  const eventId = $(this).data("id");
  const eventObj = $(this).data("event"); // stringified JSON from data-event
  let bookmarks = JSON.parse(localStorage.getItem("eventBookmarks")) || [];

  // Check if already bookmarked
  const exists = bookmarks.find(b => b.id === eventId);

  if (exists) {
    // Remove if already bookmarked
    bookmarks = bookmarks.filter(b => b.id !== eventId);
    localStorage.setItem("eventBookmarks", JSON.stringify(bookmarks));
    alert("❌ Removed from bookmarks");
    $(this).text("⭐ Bookmark").removeClass("btn-danger").addClass("btn-warning");
  } else {
    // Add new
    bookmarks.push(eventObj);
    localStorage.setItem("eventBookmarks", JSON.stringify(bookmarks));
    alert("✅ Added to bookmarks");
    $(this).text("✔ Bookmarked").removeClass("btn-warning").addClass("btn-danger");
  }
});





function loadBookmarks() {
  let bookmarks = JSON.parse(localStorage.getItem("eventBookmarks")) || [];
  let html = `
    <section class="container my-5">
      <h2 class="mb-4 text-center fw-bold text-primary">⭐ Your Bookmarked Events</h2>
      <div class="row g-4 justify-content-center">
  `;

  if (bookmarks.length === 0) {
    html += `<p class="text-center fst-italic">No bookmarks yet.</p>`;
  } else {
    bookmarks.forEach(event => {
      html += `
        <div class="col-sm-12 col-md-6 col-lg-4">
          <div class="card shadow-lg rounded-4 overflow-hidden">
            <img src="assets/img/banners/${event.image}" class="card-img-top" height="200px">
            <div class="card-body">
              <h5 class="fw-bold">${event.name}</h5>
              <p>${event.date} - ${event.endDate}</p>
              <p><i class="bi bi-clock-history"></i> ${event.time} at ${event.venue}</p>
              <button class="btn btn-danger w-100 remove-bookmark" data-id="${event.id}">
                ❌ Remove Bookmark
              </button>
            </div>
          </div>
        </div>
      `;
    });
  }

  html += `</div></section>`;
  $("#content").html(html);

  // Remove bookmark handler
  $(document).off("click", ".remove-bookmark").on("click", ".remove-bookmark", function () {
    const id = $(this).data("id");
    let bookmarks = JSON.parse(localStorage.getItem("eventBookmarks")) || [];
    bookmarks = bookmarks.filter(b => b.id !== id);
    localStorage.setItem("eventBookmarks", JSON.stringify(bookmarks));
    loadBookmarks();
  });
}










});


