// =============================
// CampusConnect SPA Script
// =============================

// Global JSON data
let campusData = {};

// Load JSON data on page load
$(document).ready(function () {
  $.getJSON("data/campusconnect.json", function (data) {
    campusData = data.campusConnect;

    // Load Home by default
    loadHome();

    // Setup navigation clicks
    setupNavigation();
  });
});

// =============================
// SPA Navigation (Hash Based)
// =============================
function setupNavigation() {
  // On page load or hash change
  $(window).on("hashchange", function () {
    navigateTo(location.hash);
  });

  // Trigger once on initial load
  navigateTo(location.hash || "#home");
}

function navigateTo(hash) {
  switch (hash) {
    case "#home": loadHome(); break;
    case "#about": loadAbout(); break;
    case "#events": loadEvents(); break;
    case "#gallery": loadGallery(); break;
    case "#contact": loadContact(); break;
    case "#feedback": loadFeedback(); break;
    default:
      $("#content").html(`<h2 class="text-center">Page Not Found</h2>`);
  }
}

// =============================
// HOME PAGE
// =============================
function loadHome() {
  let today = new Date();

  // Separate events into upcoming & past
  let upcomingEvents = campusData.events.filter(e => new Date(e.endDate) >= today);
  let pastEvents = campusData.events.filter(e => new Date(e.endDate) < today);

  // Load bookmarks from localStorage (or [] if none)
  let bookmarks = JSON.parse(localStorage.getItem("bookmarkedEvents") || "[]");

  let html = `
    <!-- Moving Welcome Message -->
    <div class="welcome-marquee text-white py-2 mt-5 bg-primary">
      <div class="marquee-text px-3 fw-semibold" style="font-size: 1.25rem;">
        ${campusData.banner.welcomeMessage}
      </div>
    </div>

    <!-- Banner Carousel -->
    <div id="carouselBanner" class="carousel slide mb-5 shadow-lg rounded" data-bs-ride="carousel" data-bs-interval="4000">
      <div class="carousel-inner rounded">
  `;

  campusData.banner.banners.forEach((banner, i) => {
    html += `
      <div class="carousel-item ${i === 0 ? 'active' : ''}">
        <img height="400px" src="assets/img/banners/${banner.image}" class="d-block w-100 rounded" alt="${banner.title}">
        <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-2">
          <h5 class="text-white fw-bold">${banner.title}</h5>
        </div>
      </div>
    `;
  });

  html += `
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselBanner" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselBanner" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>

    <!-- Upcoming Events -->
    <h3 class="mb-4 text-center fw-bold text-primary">Upcoming Events</h3>
    <div class="row g-4 justify-content-center">
  `;

  if (upcomingEvents.length === 0) {
    html += `<p class="text-center fst-italic">No upcoming events right now.</p>`;
  }

  upcomingEvents.forEach(event => {
    const isBookmarked = bookmarks.includes(event.id);

    html += `
     <div class="col-sm-12 col-md-6 col-lg-4">
      <div class="card event-card border-0 shadow-lg mb-4 hover-scale rounded-4 overflow-hidden">
        <div class="event-img-container position-relative overflow-hidden">
          <img height="280px" src="assets/img/banners/${event.image}" class="card-img-top object-fit-cover" alt="${event.name}">
          <div class="event-overlay position-absolute top-0 start-0 w-100 h-100 d-flex flex-column justify-content-between p-3">
            <div>
              <span class="badge bg-primary me-1 fs-6">${event.category}</span>
              <span class="badge bg-info text-dark fs-6">${event.department}</span>
            </div>
            <div class="text-white text-end" style="text-shadow: 0 0 6px rgba(0,0,0,0.7); font-weight: 600;">
              ${event.date} - ${event.endDate}
            </div>
          </div>
        </div>

        <div class="card-body">
          <h5 class="card-title fw-bold">${event.name}</h5>
          <p class="mb-1"><i class="bi bi-clock-history text-warning"></i> ${event.time} at ${event.venue}</p>

          <!-- Countdown -->
          <div id="countdown-${event.id}" class="countdown badge bg-dark text-white p-2 mb-3 d-inline-block fs-6 rounded-pill"></div>

          <!-- Buttons -->
          <div class="d-flex gap-2">
            <a href="#" class="btn btn-primary w-100 learn-more shadow-sm"
              data-id="${event.id}" 
              data-name="${event.name}" 
              data-description="${event.description}" 
              data-date="${event.date}" 
              data-end="${event.endDate}" 
              data-time="${event.time}" 
              data-venue="${event.venue}" 
              data-dept="${event.department}" 
              data-category="${event.category}" 
              data-img="${event.image}" 
              data-organizer="${event.organizer}" 
              data-bs-toggle="modal" 
              data-bs-target="#eventModal">
              <i class="bi bi-info-circle"></i> Learn More
            </a>
            <button class="btn ${isBookmarked ? "btn-warning" : "btn-outline-warning"} bookmark-btn" data-id="${event.id}">
              <i class="bi ${isBookmarked ? "bi-star-fill" : "bi-star"}"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
  });

  html += `</div>`;

  // 🔹 Bookmarked Events Section
  if (bookmarks.length > 0) {
    html += `
      <h3 class="mt-5 mb-4 text-center fw-bold text-warning">⭐ Your Bookmarked Events</h3>
      <div id="bookmarked-events" class="row g-4 justify-content-center"></div>
    `;
  }

  // Past events
  html += `
    <h3 class="mb-4 mt-5 text-center fw-bold text-secondary">Past Events</h3>
    <div class="row g-4 justify-content-center">
  `;

  if (pastEvents.length === 0) {
    html += `<p class="text-center fst-italic">No past events yet.</p>`;
  }

  pastEvents.forEach(event => {
    html += `
     <div class="col-sm-12 col-md-6 col-lg-4">
      <div class="card event-card border-0 shadow-sm mb-4 hover-scale rounded-4 overflow-hidden">
        <div class="event-img-container position-relative overflow-hidden">
          <img height="280px" src="assets/img/banners/${event.image}" class="card-img-top object-fit-cover" alt="${event.name}">
          <div class="event-overlay position-absolute top-0 start-0 w-100 h-100 d-flex flex-column justify-content-between p-3">
            <div>
              <span class="badge bg-primary me-1 fs-6">${event.category}</span>
              <span class="badge bg-info text-dark fs-6">${event.department}</span>
            </div>
            <div class="text-white text-end" style="text-shadow: 0 0 6px rgba(0,0,0,0.7); font-weight: 600;">
              ${event.date} - ${event.endDate}
            </div>
          </div>
        </div>

        <div class="card-body">
          <h5 class="card-title fw-bold">${event.name}</h5>
          <p class="mb-1"><i class="bi bi-clock-history text-warning"></i> ${event.time} at ${event.venue}</p>

          <a href="#" class="btn btn-outline-secondary w-100 learn-more shadow-sm"
            data-id="${event.id}" 
            data-name="${event.name}" 
            data-description="${event.description}" 
            data-date="${event.date}" 
            data-end="${event.endDate}" 
            data-time="${event.time}" 
            data-venue="${event.venue}" 
            data-dept="${event.department}" 
            data-category="${event.category}" 
            data-img="${event.image}" 
            data-organizer="${event.organizer}" 
            data-bs-toggle="modal" 
            data-bs-target="#eventModal">
            <i class="bi bi-info-circle"></i> Learn More
          </a>
        </div>
      </div>
    </div>
    `;
  });

  html += `</div>`;
  $("#content").html(html);

  // Start countdowns for upcoming only
  upcomingEvents.forEach(event => {
    startCountdown(event.id, event.date, event.time);
  });

  // Bind modal details
  $(".learn-more").click(function () {
  const name = $(this).data("name");
  const img = $(this).data("img");
  const description = $(this).data("description");
  const date = $(this).data("date");
  const end = $(this).data("end");
  const time = $(this).data("time");
  const venue = $(this).data("venue");
  const dept = $(this).data("dept");
  const category = $(this).data("category");
  const organizer = $(this).data("organizer");

  // Modal Title
  $("#eventModalLabel").text(name);

  // Modal Image
  $("#eventModalImg").attr("src", "assets/img/banners/" + img);

  // Modal Description
  $("#eventModalDesc").html(`
    <div class="alert alert-info d-flex align-items-center gap-2">
      <i class="bi bi-info-circle-fill fs-4"></i> ${description}
    </div>
  `);

  // Other Details
  $("#eventModalDetails").html(`
    <li class="list-group-item"><strong>Date:</strong> ${date} - ${end}</li>
    <li class="list-group-item"><strong>Time:</strong> ${time}</li>
    <li class="list-group-item"><strong>Venue:</strong> ${venue}</li>
    <li class="list-group-item"><strong>Department:</strong> ${dept}</li>
    <li class="list-group-item"><strong>Category:</strong> ${category}</li>
    <li class="list-group-item"><strong>Organizer:</strong> ${organizer}</li>
  `);
});

  // 🔹 Bookmark toggle handler
  $(".bookmark-btn").click(function () {
    const eventId = $(this).data("id");
    let current = JSON.parse(localStorage.getItem("bookmarkedEvents") || "[]");

    if (current.includes(eventId)) {
      current = current.filter(id => id !== eventId); // remove
    } else {
      current.push(eventId); // add
    }

    localStorage.setItem("bookmarkedEvents", JSON.stringify(current));
    loadHome(); // re-render
  });

  // 🔹 Render bookmarked section if needed
  if (bookmarks.length > 0) {
    let bookmarkedHtml = "";
    campusData.events
      .filter(ev => bookmarks.includes(ev.id))
      .forEach(ev => {
        bookmarkedHtml += `
          <div class="col-sm-12 col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100">
              <img height="300px" src="assets/img/banners/${ev.image}" class="card-img-top" alt="${ev.name}">
              <div class="card-body">
                <h5 class="card-title">${ev.name}</h5>
                <p class="small text-light">${ev.date} at ${ev.venue}</p>
              </div>
            </div>
          </div>
        `;
      });

    $("#bookmarked-events").html(bookmarkedHtml);
  }
}




 // Handle Bookmark Click
$(document).off("click", ".bookmark-btn").on("click", ".bookmark-btn", function () {
  const eventId = $(this).data("id");
  const eventObj = $(this).data("event"); // stringified JSON from data-event
  let bookmarks = JSON.parse(localStorage.getItem("eventBookmarks")) || [];

  // Check if already bookmarked
  const exists = bookmarks.find(b => b.id === eventId);

  if (exists) {
    // Remove if already bookmarked
    bookmarks = bookmarks.filter(b => b.id !== eventId);
    localStorage.setItem("eventBookmarks", JSON.stringify(bookmarks));
    alert("❌ Removed from bookmarks");
    $(this).text("⭐ Bookmark").removeClass("btn-danger").addClass("btn-warning");
  } else {
    // Add new
    bookmarks.push(eventObj);
    localStorage.setItem("eventBookmarks", JSON.stringify(bookmarks));
    alert("✅ Added to bookmarks");
    $(this).text("✔ Bookmarked").removeClass("btn-warning").addClass("btn-danger");
  }
});





function loadBookmarks() {
  let bookmarks = JSON.parse(localStorage.getItem("eventBookmarks")) || [];
  let html = `
    <section class="container my-5">
      <h2 class="mb-4 text-center fw-bold text-primary">⭐ Your Bookmarked Events</h2>
      <div class="row g-4 justify-content-center">
  `;

  if (bookmarks.length === 0) {
    html += `<p class="text-center fst-italic">No bookmarks yet.</p>`;
  } else {
    bookmarks.forEach(event => {
      html += `
        <div class="col-sm-12 col-md-6 col-lg-4">
          <div class="card shadow-lg rounded-4 overflow-hidden">
            <img src="assets/img/banners/${event.image}" class="card-img-top" height="200px">
            <div class="card-body">
              <h5 class="fw-bold">${event.name}</h5>
              <p>${event.date} - ${event.endDate}</p>
              <p><i class="bi bi-clock-history"></i> ${event.time} at ${event.venue}</p>
              <button class="btn btn-danger w-100 remove-bookmark" data-id="${event.id}">
                ❌ Remove Bookmark
              </button>
            </div>
          </div>
        </div>
      `;
    });
  }

  html += `</div></section>`;
  $("#content").html(html);

  // Remove bookmark handler
  $(document).off("click", ".remove-bookmark").on("click", ".remove-bookmark", function () {
    const id = $(this).data("id");
    let bookmarks = JSON.parse(localStorage.getItem("eventBookmarks")) || [];
    bookmarks = bookmarks.filter(b => b.id !== id);
    localStorage.setItem("eventBookmarks", JSON.stringify(bookmarks));
    loadBookmarks();
  });
}



// =============================
// ABOUT PAGE
// =============================
function loadAbout() {
  // College Info
  const collegeName = "CampusConnect College of Engineering";
  const location = "Karachi";
  const affiliation = "FAST University";

  // Highlights (keep from your current hero section)
  const highlights = [
    { icon: "bi-award-fill", color: "primary", title: "Recognized Excellence", desc: "Ranked among the top institutes in technology & innovation." },
    { icon: "bi-people-fill", color: "success", title: "Cultural Diversity", desc: "Annual events & festivals celebrating talent and creativity." },
    { icon: "bi-mortarboard-fill", color: "danger", title: "Academic Brilliance", desc: "Strong focus on innovation, research, and skill-building." }
  ];

  // Group key events by category from campusData.events
  // Filter to only upcoming and relevant key events (you can decide criteria)
  const events = campusData.events;
    const departments = campusData.departments;

  // We'll group by category for the overview
  const eventCategories = {};
  events.forEach(ev => {
    if (!eventCategories[ev.category]) {
      eventCategories[ev.category] = [];
    }
    eventCategories[ev.category].push(ev);
  });

  // Contacts for organizers (filter to those who have organizing roles)
  const organizers = campusData.contacts.filter(c => {
    const orgRoles = ["Faculty", "Student"]; // You may add other logic if needed
    return orgRoles.includes(c.role);
  });

  let html = ``;

  // Hero Section - College Info and Highlights
  html += `
  <section class="mt-5 about-hero text-center text-white d-flex align-items-center justify-content-center"
    style="background: linear-gradient(rgba(0,0,50,0.7), rgba(5, 5, 56, 0.7)), url('assets/img/hero-section.jpeg') center/cover no-repeat; height: 60vh; border-radius: 0 0 50px 50px;">
    <div class="container">
      <h1 class="display-4 fw-bold mb-3">${collegeName}</h1>
      <p class="lead mb-4">Located in ${location}, affiliated with <strong>${affiliation}</strong>.  
        A hub for academic excellence, innovation, and vibrant cultural activities.</p>
      <div class="row justify-content-center">
  `;

  highlights.forEach(h => {
    html += `
      <div class="col-md-3 mb-3">
        <div class="card bg-light text-dark border-0 shadow-sm h-100">
          <div class="card-body">
            <i class="bi ${h.icon} text-${h.color} display-5"></i>
            <h6 class="mt-2 fw-bold">${h.title}</h6>
            <p class="small">${h.desc}</p>
          </div>
        </div>
      </div>
    `;
  });

  html += `
      </div>
    </div>
  </section>
  `;


// html += `
//   <section class="container my-5">
//     <h2 class="mb-5 fw-bold border-bottom pb-3 text-center">Departments</h2>
//     <div class="row">
// `;

fetch('data/campusconnect.json')
  .then(res => res.json())
  .then(res => {
    if (res.departments && Array.isArray(res.departments)) {
      
      res.departments.forEach(department => {
        html += `
          <div class="col-md-4 mb-4">
            <div class="card bg-dark text-white shadow-lg h-100">
              <div class="card-body">
                <h5 class="card-title">${department.name}</h5>
                <p class="card-text"><strong>Head:</strong> ${department.head}</p>
                <p><strong>Location:</strong> ${department.location}</p>
                <ul>
                  ${department.highlights.map(h => `<li>${h}</li>`).join("")}
                </ul>
              </div>
            </div>
          </div>
        `;
      });
    } else {
      html += `<p class="text-danger">No department data found.</p>`;
    }

    html += `
        </div>
      </section>
    `;


    
  })

  // Key Annual Events Overview
html += `
  <section class="container my-5">
    <h2 class="mb-5 fw-bold border-bottom pb-3 text-center">Key Annual Events</h2>
`;

Object.entries(eventCategories).forEach(([category, events]) => {
  // Sort events by date ascending
  events.sort((a, b) => new Date(a.date) - new Date(b.date));

  html += `
    <div class="mb-5">
      <h4 class="text-primary fw-semibold mb-3">${category} Events</h4>
      <ul class="list-group shadow-sm rounded">
  `;

  events.forEach(ev => {
    const eventDate = new Date(ev.date);
    const monthName = eventDate.toLocaleString('default', { month: 'long' });
    const day = eventDate.getDate();

    html += `
      <li class="list-group-item d-flex align-items-center gap-3 py-3">
        <div class="event-date bg-primary text-white text-center rounded-3 flex-shrink-0" style="width: 60px;">
          <div class="month text-uppercase small">${monthName.slice(0,3)}</div>
          <div class="day fs-4 fw-bold">${day}</div>
        </div>
        <div>
          <h5 class="mb-1 fw-semibold">${ev.name}</h5>
          <p class="mb-0 text-muted">${ev.description}</p>
        </div>
      </li>
    `;
  });

  html += `
      </ul>
    </div>
  `;
});

html += `</section>`;





    



  // Organizing Bodies / Teams
  html += `
    <section class="container my-5">
      <h2 class="mb-4">Organizing Bodies & Teams</h2>
      <div class="row">
  `;

  organizers.forEach(org => {
    html += `
      <div class="col-md-4 mb-4">
        <div class="card border-0 shadow-sm h-100">
          <img src="${org.photo}" class="card-img-top rounded-circle mx-auto mt-3" alt="${org.name}" style="width: 150px; height: 150px; object-fit: cover;">
          <div class="card-body text-center">
            <h5 class="card-title">${org.name}</h5>
            <p class="card-text"><em>${org.designation}</em></p>
            <p class="small text-muted">${org.department}</p>
            <p class="small mb-1"><i class="bi bi-telephone"></i> ${org.phone}</p>
            <p class="small"><i class="bi bi-envelope"></i> ${org.email}</p>
          </div>
        </div>
      </div>
    `;
  });

  html += `
      </div>
    </section>
  `;

  $("#content").html(html);
}



// =============================
// EVENTS PAGE
// =============================
let currentCategory = "all";
let currentSort = "date";
let bookmarks = JSON.parse(localStorage.getItem("bookmarks")) || [];

function loadEvents() {
  // Category Tabs (added Bookmarked tab)
  const tabsHtml = `
    <ul class="nav nav-tabs mb-4 justify-content-center" id="categoryTabs" style="margin-top:100px; gap: 12px; flex-wrap: wrap;">
      <li class="nav-item"><button class="nav-link rounded-pill px-4 py-2 fw-semibold ${currentCategory === "all" ? "active" : ""}" data-category="all"><i class="bi bi-list-ul me-1"></i> All</button></li>
      <li class="nav-item"><button class="nav-link rounded-pill px-4 py-2 fw-semibold ${currentCategory === "Academic" ? "active" : ""}" data-category="Academic"><i class="bi bi-book me-1"></i> Academic</button></li>
      <li class="nav-item"><button class="nav-link rounded-pill px-4 py-2 fw-semibold ${currentCategory === "Cultural" ? "active" : ""}" data-category="Cultural"><i class="bi bi-music-note-beamed me-1"></i> Cultural</button></li>
      <li class="nav-item"><button class="nav-link rounded-pill px-4 py-2 fw-semibold ${currentCategory === "Sports" ? "active" : ""}" data-category="Sports"><i class="bi bi-trophy me-1"></i> Sports</button></li>
      <li class="nav-item"><button class="nav-link rounded-pill px-4 py-2 fw-semibold ${currentCategory === "Departmental" ? "active" : ""}" data-category="Departmental"><i class="bi bi-building me-1"></i> Departmental</button></li>
      <li class="nav-item"><button class="nav-link rounded-pill px-4 py-2 fw-semibold ${currentCategory === "bookmarked" ? "active" : ""}" data-category="bookmarked"><i class="bi bi-bookmark-star me-1"></i> Bookmarked</button></li>
    </ul>
  `;

  // Sort Dropdown
  const sortHtml = `
    <div class="row mb-3">
      <div class="col-md-4 offset-md-4">
        <select id="sortBy" class="form-select">
          <option value="date" ${currentSort === "date" ? "selected" : ""}>Sort by Date</option>
          <option value="name" ${currentSort === "name" ? "selected" : ""}>Sort by Name</option>
          <option value="category" ${currentSort === "category" ? "selected" : ""}>Sort by Category</option>
        </select>
      </div>
    </div>
  `;

  // ✅ Filter events
  let filteredEvents = [];
  if (currentCategory === "bookmarked") {
    filteredEvents = bookmarks; // show only saved bookmarks
  } else {
    filteredEvents = campusData.events;
    if (currentCategory !== "all") {
      filteredEvents = filteredEvents.filter(e => e.category === currentCategory);
    }
  }

  // ✅ Sort events
  filteredEvents.sort((a, b) => {
    if (currentSort === "date") return new Date(a.date) - new Date(b.date);
    if (currentSort === "name") return a.name.localeCompare(b.name);
    if (currentSort === "category") return a.category.localeCompare(b.category);
    return 0;
  });

  // ✅ Build event cards
  let eventsHtml = `<div class="row g-4">`;
  if (filteredEvents.length === 0) {
    eventsHtml += `<p class="text-center text-muted">No events found.</p>`;
  } else {
    filteredEvents.forEach(event => {
      const isBookmarked = bookmarks.some(b => b.id === event.id);
      eventsHtml += `
        <div class="col-md-4">
          <div class="card shadow-sm h-100">
            <img style="height:250px; object-fit:cover;" src="assets/img/banners/${event.image}" class="card-img-top" alt="${event.name}">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">${event.name}</h5>
              <p class="mb-1"><i class="bi bi-calendar-event"></i> ${event.date}</p>
              <p class="mb-1"><i class="bi bi-geo-alt"></i> ${event.venue}</p>
              <p class="text-light small mb-2">${event.description?.substring(0, 80) || ""}...</p>
             

              <div class="mt-auto d-flex justify-content-between align-items-center">
                <button 
                  class="btn btn-outline-primary btn-lg col-lg-10 learn-more"
                  data-bs-toggle="modal"
                  data-bs-target="#eventModal"
                  data-id="${event.id}"
                  data-name="${event.name}"
                  data-description="${event.description || ""}"
                  data-date="${event.date}"
                  data-end="${event.endDate || ''}"
                  data-time="${event.time || ''}"
                  data-venue="${event.venue}"
                  data-category="${event.category || ''}"
                  data-dept="${event.department || ''}"
                  data-img="${event.image}"
                  data-organizer="${event.organizer || 'N/A'}">
                  <i class="bi bi-info-circle"></i> Learn More
                </button>

                <button class="btn btn-sm bookmark-btn ${isBookmarked ? "btn-warning" : "btn-outline-warning"}" 
                        data-id="${event.id}" 
                        data-name="${event.name}" 
                        data-date="${event.date}" 
                        data-venue="${event.venue}" 
                        data-img="${event.image}">
                  <i class="bi ${isBookmarked ? "bi-bookmark-star-fill" : "bi-bookmark"}"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    });
  }
  eventsHtml += `</div>`;

  // Inject into DOM
  $("#content").html(tabsHtml + sortHtml + eventsHtml);

  // Category tab clicks
  $("#categoryTabs button").on("click", function() {
    currentCategory = $(this).data("category");
    loadEvents();
  });

  // Sort dropdown change
  $("#sortBy").on("change", function() {
    currentSort = $(this).val();
    loadEvents();
  });

  // Bookmark toggle
  $(".bookmark-btn").on("click", function() {
    const $btn = $(this);
    const event = {
      id: $btn.data("id"),
      name: $btn.data("name"),
      date: $btn.data("date"),
      venue: $btn.data("venue"),
      image: $btn.data("img")
    };
    const index = bookmarks.findIndex(b => b.id === event.id);

    if (index === -1) {
      bookmarks.push(event);
      $btn.removeClass("btn-outline-warning").addClass("btn-warning");
      $btn.find("i").removeClass("bi-bookmark").addClass("bi-bookmark-star-fill");
    } else {
      bookmarks.splice(index, 1);
      $btn.removeClass("btn-warning").addClass("btn-outline-warning");
      $btn.find("i").removeClass("bi-bookmark-star-fill").addClass("bi-bookmark");
    }

    localStorage.setItem("bookmarks", JSON.stringify(bookmarks));

    // ✅ Refresh if in "Bookmarked" tab
    if (currentCategory === "bookmarked") loadEvents();
  });

  // Modal details
  $(".learn-more").click(function () {
    const name = $(this).data("name");
    const img = $(this).data("img");
    const description = $(this).data("description");
    const date = $(this).data("date");
    const end = $(this).data("end");
    const time = $(this).data("time");
    const venue = $(this).data("venue");
    const dept = $(this).data("dept");
    const category = $(this).data("category");
    const organizer = $(this).data("organizer");

    $("#eventModalLabel").text(name);
    $("#eventModalImg").attr("src", "assets/img/banners/" + img);
    $("#eventModalDesc").html(`
      <div class="alert alert-info d-flex align-items-center gap-2">
        <i class="bi bi-info-circle-fill fs-4"></i> ${description}
      </div>
    `);
    $("#eventModalDetails").html(`
      <li class="list-group-item"><strong>Date:</strong> ${date} ${end ? `- ${end}` : ""}</li>
      <li class="list-group-item"><strong>Time:</strong> ${time}</li>
      <li class="list-group-item"><strong>Venue:</strong> ${venue}</li>
      <li class="list-group-item"><strong>Department:</strong> ${dept}</li>
      <li class="list-group-item"><strong>Category:</strong> ${category}</li>
      <li class="list-group-item"><strong>Organizer:</strong> ${organizer}</li>
    `);
  });
}








// =============================
// GALLERY PAGE
// =============================
function loadGallery() {
  let html = `
    <h2 class="mb-4 text-center" style="margin-top:100px">Gallery Page</h2>

    <!-- Gallery Tabs -->
   <ul class="nav nav-tabs justify-content-center mb-4" id="galleryTabs" role="tablist" style="border-bottom: none;">
  <li class="nav-item" role="presentation">
    <a class="nav-link active rounded-pill px-4 py-2 shadow-sm" href="#" data-mode="year" role="tab" aria-selected="true">
      <i class="bi bi-calendar3 me-2"></i> By Year
    </a>
  </li>
  <li class="nav-item ms-3" role="presentation">
    <a class="nav-link rounded-pill px-4 py-2 shadow-sm" href="#" data-mode="category" role="tab" aria-selected="false">
      <i class="bi bi-tags me-2"></i> By Category
    </a>
  </li>
</ul>

    <!-- Gallery Content -->
    <div id="galleryContent"></div>

    <!-- Modal for Image Preview -->
    <div class="modal fade" id="galleryModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-body p-0">
            <img id="galleryModalImg" src="" class="img-fluid w-100 rounded">
          </div>
        </div>
      </div>
    </div>
  `;

  $("#content").html(html);

  let currentMode = "year"; // default view

  function renderGallery() {
    let grouped = {};

    // -------- Group Event Images --------
    campusData.events.forEach(event => {
      let eventYear = new Date(event.date).getFullYear();
      let key = currentMode === "year" ? `${eventYear}` : event.category;

      if (!grouped[key]) grouped[key] = [];
      grouped[key].push({
        img: `assets/img/banners/${event.image}`,
        name: event.name,
        date: event.date
      });
    });

    // -------- Render Images --------
    let innerHtml = ``;
    Object.keys(grouped).forEach(key => {
      innerHtml += `<h4 class="mt-4">${key}</h4><div class="row mb-4">`;

      grouped[key].forEach(event => {
        innerHtml += `
          <div class="col-md-3 col-sm-6 mb-3">
            <div class="card border-0 shadow-sm" >
              <img style="height:300px"  src="${event.img}" 
                   class="img-fluid rounded gallery-img" 
                   alt="${event.name}"
                   data-bs-toggle="modal" 
                   data-bs-target="#galleryModal" 
                   data-img="${event.img}">
              <div class="card-body p-2 text-center">
                <small class="fw-bold d-block">${event.name}</small>
                <small class="text-muted">${event.date}</small>
              </div>
            </div>
          </div>
        `;
      });

      innerHtml += `</div>`;
    });

    $("#galleryContent").html(innerHtml);

    // Preview Modal
    $(".gallery-img").click(function () {
      $("#galleryModalImg").attr("src", $(this).data("img"));
    });
  }

  // Tab switching
  $("#galleryTabs .nav-link").click(function (e) {
    e.preventDefault();
    $("#galleryTabs .nav-link").removeClass("active");
    $(this).addClass("active");
    currentMode = $(this).data("mode");
    renderGallery();
  });

  // Initial load
  renderGallery();
}

// =============================
// CONTACT PAGE
// =============================
function loadContact() {
  let html = `
    <div class="container my-5">
      <h2 class="text-center mb-5 fw-bold text-white" style="margin-top:100px">📞 Meet Our Coordinators</h2>

      <!-- Tabs -->
      <ul class="nav nav-pills justify-content-center mb-4 gap-3" id="contactTabs" role="tablist">
        <li class="nav-item" role="presentation">
          <button class="nav-link active px-4 py-2 rounded-pill shadow-sm text-white bg-primary border-0" 
                  id="faculty-tab" data-bs-toggle="tab" data-bs-target="#faculty" type="button" role="tab">
            👩‍🏫 Faculty
          </button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link px-4 py-2 rounded-pill shadow-sm text-white bg-success border-0" 
                  id="student-tab" data-bs-toggle="tab" data-bs-target="#student" type="button" role="tab">
            🎓 Students
          </button>
        </li>
      </ul>

      <div class="tab-content">
        <!-- Faculty Tab -->
        <div class="tab-pane fade show active" id="faculty" role="tabpanel">
          <div class="row g-4">
  `;

  // Faculty Contacts
  campusData.contacts
    .filter(p => p.role === "Faculty")
    .forEach(person => {
      html += `
        <div class="col-md-4">
          <div class="card border-0 shadow-lg rounded-4 h-100 hover-card bg-dark text-white">
            <div class="text-center p-4">
              <img src="${person.photo}" class="rounded-circle mb-3 shadow-sm border border-3 border-light" 
                   alt="${person.name}" style="width:120px; height:120px; object-fit:cover;">
              <h5 class="fw-bold">${person.name}</h5>
              <p class="mb-1 text-light">${person.designation}</p>
              <p class="small"><i class="bi bi-building"></i> ${person.department}</p>
              <hr class="border-light">
              <p class="mb-1"><i class="bi bi-telephone-fill text-success"></i> 
                <a href="tel:${person.phone}" class="text-decoration-none text-info">${person.phone}</a>
              </p>
              <p><i class="bi bi-envelope-fill text-danger"></i> 
                <a href="mailto:${person.email}" class="text-decoration-none text-warning">${person.email}</a>
              </p>
              <span class="badge bg-primary px-3 py-2">${person.role}</span>
            </div>
          </div>
        </div>
      `;
    });

  html += `
          </div>
        </div>

        <!-- Student Tab -->
        <div class="tab-pane fade" id="student" role="tabpanel">
          <div class="row g-4">
  `;

  // Student Contacts
  campusData.contacts
    .filter(p => p.role === "Student")
    .forEach(person => {
      html += `
        <div class="col-md-4">
          <div class="card border-0 shadow-lg rounded-4 h-100 hover-card bg-secondary text-white">
            <div class="text-center p-4">
              <img src="${person.photo}" class="rounded-circle mb-3 shadow-sm border border-3 border-light" 
                   alt="${person.name}" style="width:120px; height:120px; object-fit:cover;">
              <h5 class="fw-bold">${person.name}</h5>
              <p class="mb-1 text-light">${person.designation}</p>
              <p class="small"><i class="bi bi-building"></i> ${person.department}</p>
              <hr class="border-light">
              <p class="mb-1"><i class="bi bi-telephone-fill text-success"></i> 
                <a href="tel:${person.phone}" class="text-decoration-none text-info">${person.phone}</a>
              </p>
              <p><i class="bi bi-envelope-fill text-danger"></i> 
                <a href="mailto:${person.email}" class="text-decoration-none text-warning">${person.email}</a>
              </p>
              <span class="badge bg-success px-3 py-2">${person.role}</span>
            </div>
          </div>
        </div>
      `;
    });

  html += `
          </div>
        </div>
      </div>

      <!-- Google Map -->
      <div class="mt-5">
        <h4 class="mb-3 fw-bold text-white">📍 Our Campus Location</h4>
        <div class="ratio ratio-16x9 shadow rounded-4 border border-light">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3620.0170064238873!2d67.07182317586773!3d24.86326874514427!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33ea3db108f41%3A0x42acc4507358b160!2sAptech%20Learning%2C%20Shahrah%20e%20Faisal%20Center!5e0!3m2!1sen!2s!4v1757518007014!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>

    <style>
      body { background: #121212; }  /* Dark background */
      .hover-card { transition: transform 0.3s ease, box-shadow 0.3s ease; }
      .hover-card:hover { transform: translateY(-8px); box-shadow: 0 12px 30px rgba(255,255,255,0.2); }
    </style>
  `;

  $("#content").html(html);
}


// =============================
// FEEDBACK PAGE
// =============================
function loadFeedback() {
  let html = `
    <div class="container feedback my-5 mt-5" style="max-width: 800px;">
      <h2 class="text-center mb-4" style="margin-top:100px">📝 Feedback Form</h2>
      <p class="text-center text-muted">
        Share your thoughts about our recent events. Your feedback helps us improve!
      </p>

      <form id="feedbackForm" class="shadow-lg p-4 rounded bg-light" novalidate>
        <!-- Name -->
        <div class="mb-3">
          <label for="feedbackName" class="form-label fw-bold">Name</label>
          <input type="text" class="form-control" id="feedbackName" placeholder="Enter your full name" required pattern="^[a-zA-Z\s]+$" />
          <div class="invalid-feedback">
            Please enter a valid name (letters and spaces only).
          </div>
        </div>

        <!-- Email -->
        <div class="mb-3">
          <label for="feedbackEmail" class="form-label fw-bold">Email</label>
          <input type="email" class="form-control" id="feedbackEmail" placeholder="Enter your email" required
            pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" />
          <div class="invalid-feedback">
            Please enter a valid email address.
          </div>
        </div>

        <!-- User Type -->
        <div class="mb-3">
          <label for="feedbackUserType" class="form-label fw-bold">User Type</label>
          <select class="form-select" id="feedbackUserType" required>
            <option value="" selected disabled>Select your role</option>
            <option>Student</option>
            <option>Faculty</option>
            <option>Guest</option>
          </select>
          <div class="invalid-feedback">
            Please select your user type.
          </div>
        </div>

        <!-- Event Attended -->
        <div class="mb-3">
          <label for="feedbackEvent" class="form-label fw-bold">Event Attended</label>
          <select class="form-select" id="feedbackEvent" required>
            <option value="" selected disabled>Select an event</option>
          </select>
          <div class="invalid-feedback">
            Please select an event.
          </div>
        </div>

        <!-- Rating with Stars -->
        <div class="mb-3">
          <label class="form-label fw-bold">Rating</label>
          <div id="starRating" class="d-flex gap-2 fs-3 text-warning" role="radiogroup" aria-label="Star rating">
            <i class="bi bi-star" data-value="1" role="radio" aria-checked="false" tabindex="0"></i>
            <i class="bi bi-star" data-value="2" role="radio" aria-checked="false" tabindex="-1"></i>
            <i class="bi bi-star" data-value="3" role="radio" aria-checked="false" tabindex="-1"></i>
            <i class="bi bi-star" data-value="4" role="radio" aria-checked="false" tabindex="-1"></i>
            <i class="bi bi-star" data-value="5" role="radio" aria-checked="false" tabindex="-1"></i>
          </div>
          <input type="hidden" id="feedbackRating" value="0" required />
          <div class="invalid-feedback d-block" id="ratingFeedback" style="display:none;">
            Please provide a rating.
          </div>
        </div>

        <!-- Comments -->
        <div class="mb-3">
          <label for="feedbackComments" class="form-label fw-bold">Comments</label>
          <textarea class="form-control" id="feedbackComments" rows="4" placeholder="Write your suggestions here..." required></textarea>
          <div class="invalid-feedback">
            Please enter your comments.
          </div>
        </div>

        <!-- Button -->
        <button type="submit" class="btn btn-primary w-100">
          <i class="bi bi-send"></i> Submit Feedback
        </button>
      </form>
    </div>
  `;

  // Render into page
  $("#content").html(html);

  // Populate Event Attended (last 1 month events)
  let today = new Date();
  let oneMonthAgo = new Date();
  oneMonthAgo.setMonth(today.getMonth() - 1);

  let eventDropdown = $("#feedbackEvent");
  let pastMonthEvents = campusData.events.filter(e => {
    let eventDate = new Date(e.date);
    return eventDate >= oneMonthAgo && eventDate <= today;
  });

  if (pastMonthEvents.length === 0) {
    eventDropdown.append(`<option disabled>No recent events</option>`);
  } else {
    pastMonthEvents.forEach(event => {
      eventDropdown.append(`<option>${event.name}</option>`);
    });
  }

  // Star Rating Logic
  $("#starRating i").on("click keydown", function (e) {
    if (e.type === "click" || (e.type === "keydown" && (e.key === "Enter" || e.key === " "))) {
      e.preventDefault();
      let rating = $(this).data("value");
      $("#feedbackRating").val(rating);

      // Highlight stars
      $("#starRating i").each(function () {
        if ($(this).data("value") <= rating) {
          $(this).removeClass("bi-star").addClass("bi-star-fill").attr("aria-checked", "true").attr("tabindex", "0");
        } else {
          $(this).removeClass("bi-star-fill").addClass("bi-star").attr("aria-checked", "false").attr("tabindex", "-1");
        }
      });

      // Hide rating validation message if shown
      $("#ratingFeedback").hide();
    }
  });

  // Form Validation and Submission
  $("#feedbackForm").on("submit", function (e) {
    e.preventDefault();

    // Use built-in HTML5 validation first
    if (!this.checkValidity()) {
      e.stopPropagation();
      $(this).addClass("was-validated");
      return;
    }

    // Additional validation for rating (hidden input)
    if ($("#feedbackRating").val() === "0") {
      $("#ratingFeedback").show();
      return;
    } else {
      $("#ratingFeedback").hide();
    }

    // If all valid, show thank you message
    $(this).removeClass("was-validated");

    $("#content").html(`
      <div class="container my-5 text-center">
        <h2 class="text-success"><i class="bi bi-check-circle-fill"></i> Thank you for your feedback!</h2>
        <p>We appreciate your time and effort to help us improve our events.</p>
        <button class="btn btn-primary mt-3" id="backToFeedback">Submit Another Feedback</button>
      </div>
    `);

    // Back to feedback form
    $("#backToFeedback").on("click", () => {
      loadFeedback();
    });
  });
}




// =============================
// Countdown Function
// =============================
function startCountdown(id, date, time) {
  let target = new Date(date + " " + time.split("-")[0].trim()).getTime();

  let interval = setInterval(function() {
    let now = new Date().getTime();
    let distance = target - now;

    if (distance < 0) {
      $("#countdown-" + id).html("Event Started");
      clearInterval(interval);
      return;
    }

    let days = Math.floor(distance / (1000 * 60 * 60 * 24));
    let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let mins = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    let secs = Math.floor((distance % (1000 * 60)) / 1000);

    $("#countdown-" + id).html(`${days}d ${hours}h ${mins}m ${secs}s`);
  }, 1000);
}
